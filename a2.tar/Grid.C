
#include "Grid.H"

using Position = std::pair<int, int>;
using fScore = std::pair< Position, double>;

///////////////////////////////////////////////////////////////////////////////
// Helper functions
///////////////////////////////////////////////////////////////////////////////

// A helper function for a priority queue
struct fScoreCompare {
    bool operator()(const fScore& l, const std::pair<std::pair<int, int>, double>& r)  
    {  
        return l.second < r.second;  
    } 
};

// A generator to create all neighbour positions at request time
struct GenNeighbour{
    GenNeighbour(const Position &pos){
        storedPos = Position(pos.first, pos.second);
        
        // Neighbour (+1, +0)
        lastGenerated = Position(pos.first, pos.second);
    }

    Position next(){
        if(lastGenerated.first == storedPos.first && lastGenerated.second == storedPos.second){
            lastGenerated.first = storedPos.first + 1;
            return lastGenerated;
        }else if(lastGenerated.first == storedPos.first+1 && lastGenerated.second == storedPos.second){
            // Neighbour (+1, 0) -> Neighbour(+1, +1)
            lastGenerated.second += 1;
            return lastGenerated;
        } else if(lastGenerated.first == storedPos.first+1 && lastGenerated.second == storedPos.second + 1){
            // Neighbour (+1, +1) -> Neighbour(+1, -1)
            lastGenerated.second = storedPos.second -1;
            return lastGenerated;
        } else if(lastGenerated.first == storedPos.first+1 && lastGenerated.second == storedPos.second - 1){
            // Neighbour (+1, -1) -> Neighbour(0, -1)
             lastGenerated.first = storedPos.first;
             return lastGenerated;
        } else if(lastGenerated.first == storedPos.first && lastGenerated.second == storedPos.second - 1){
            // Neighbour (0, -1) -> Neighbour(0, +1)
             lastGenerated.second = storedPos.second + 1;
             return lastGenerated;
        } else if(lastGenerated.first == storedPos.first && lastGenerated.second == storedPos.second + 1){
            // Neighbour (0, +1) -> Neighbour(-1, +1)
             lastGenerated.first = storedPos.first - 1;
             return lastGenerated;
        } else if(lastGenerated.first == storedPos.first-1 && lastGenerated.second == storedPos.second + 1){
            // Neighbour (-1, +1) -> Neighbour(-1, 0)
             lastGenerated.second = storedPos.second;
             return lastGenerated;
        }else if(lastGenerated.first == storedPos.first-1 && lastGenerated.second == storedPos.second){
            // Neighbour (-1, 0) -> Neighbour(-1, -1)
             lastGenerated.second = storedPos.second -1;
             return lastGenerated;
        } else {
            throw "Can't generate anymore neighbours";
        }
    }
private:
    Position lastGenerated;
    Position storedPos;
};
///////////////////////////////////////////////////////////////////////////////
// Class implementation
///////////////////////////////////////////////////////////////////////////////

// no changes in the public interface!

// data

// enum Tile { GROUND, WATER, BLOCKED };
    
// enum Direction { N, NE, E, SE, S, SW, W, NW };
    
// static const int CARDINAL_COST = 100; // Cost to move in cardinal direction
// static const int DIAGONAL_COST = 142; // Cost to move diagonally
// (>100*sqrt(2) => air distance is admissible)

// methods
bool Grid::canFloodFill(int size, int x1, int y1, int x2, int y2)const{

    // Currently can't cache all visited nodes and track whether they lead
    // to the target, would have to recursively floodfill for that to happen
    std::vector< std::pair<int,int> > queue;
    static std::set< std::pair<int,int> > visited;
    
    Grid::Tile currentType = getTile(x1,y1);
    
    if(getTile(x1,y1) != getTile(x2, y2)){
        // If the current tile we're visiting does not match our type, we've
        // reached a dead end
        visited.clear();
        return false;
    }
    
    // add node to queue
    queue.push_back(std::make_pair(x1, y1));
    while(!queue.empty()){
        // Grab first element off stack
        std::pair<int, int> currentNode = queue.back();
        
        // Delete it off the stack
        queue.pop_back();
        int x = currentNode.first; int y = currentNode.second;
        
        //Early exit
        if(x == x2 && y == y2){
        // If them node we're looking to visit is the same as the one we're
        // currently visiting, we're done
            visited.clear();
            return true;
        }
        // Move tile west until a boundary is found
        int w = x;
        while(getTile(w, y) == currentType){
            w--;
        }
        //Move tile east until a boundary is found
        int e = x;
        while(getTile(e, y) == currentType){
            e++;
        }

        //Go through all nodes between east and west and add their them to the queue
        for(int i=w; i<e; i++){
            // Keep track of all visited nodes
            visited.insert(std::pair<int,int>(i, y));

            // Traverse node to north if it's the same type as our goal type
            // and if we have not visited it before
            if(visited.count(std::pair<int,int>(i, y+1)) == 0 && 
               getTile(x,y+1) == getTile(x2, y2)){
                queue.push_back(std::pair<int, int>(i, y+1));
            }

            // Traverse node to south if it's the same type as our goal type
            // and if we have not visited it before
            if(visited.count(std::pair<int,int>(i, y-1)) == 0 &&
               getTile(x,y-1) == getTile(x2, y2)){
                queue.push_back(std::pair<int, int>(i, y-1));
            }
        }
    }
    return false;
}


Grid::Grid(int width, int height){
    _width = width;
    _height = height;

    // Initialize all tiles to Blocked
    // It's set to blocked and not ground, for now atleast so that it ensures I
    // initialize it to something
    for(int i=0; i < _width; i++){
        tiles.push_back(std::vector<Tile>());
        for(int j=0; j < _height; j++){
            tiles[i].push_back(BLOCKED);
        }
    }
}

Grid::~Grid(){};
    
// Map properties
int Grid::getWidth() const{
    return _width;
};
int Grid::getHeight() const{
    return _height;
}

Grid::Tile Grid::getTile(int x, int y) const{
  return tiles[x][y];  
};
    
// Pathfinding operations

// Return true iff object with a given size can reside on (x1, y1)
// and move from there to (x2, y2) while staying at the same tile
// type without colliding. 
//
// This should execute faster than calling findShortestPath().
// 
// Also, if the map hasn't changed, subsequent calls with the same
// x1,y1,x2,y2 coordinates SHOULD BE MUCH FASTER. Hint: flood fill + caching
bool Grid::isConnected(int size, int x1, int y1, int x2, int y2)const{
    // Build the key
    std::string key = "";
    static std::map<std::string, bool> collisionCache;
    key += std::to_string(size) + std::to_string(x1) + std::to_string(y1) + std::to_string(x2) + std::to_string(y2);
    
    std::map<std::string, bool>::const_iterator iter = collisionCache.find(key);

    if(iter != collisionCache.end()){
        return iter->second;
    } else {
        bool canFF = this->canFloodFill(size, x1, y1, x2, y2);
        collisionCache.insert(std::pair<std::string, bool>(key, canFF));
        return canFF;
    };
};

// Compute a shortest path from (x1, y1) to (x2, y2) for an object with a
// given size using A*. Store the shortest path into path, and return the
// cost of that path (using CARDINAL_COST for the moves N, E, S, and W, and
// DIAGONAL_COST for the moves NE, SE, SW, and NW) or -1 if there is no
// path. Reduce initialization time by using the generation counter trick.
int Grid::findShortestPath(int size, int x1, int y1, int x2, int y2, 
                     std::vector<Direction> &path) const{
    int totalCost = -1;
    // Starting node
    Position key = Position(x1, y1);

    // Set of all visited nodes
    std::set< Position > visited;
    std::set< Position > unvisited;
    // Collection of nodes to visit
    std::priority_queue< fScore, std::vector<fScore>, fScoreCompare> fScoreQueue;
    fScoreQueue.push( fScore(key, this->rectDistance(x1, y1, x2, y2)));
    //cameFrom
    std::map< Position, Position > cameFrom;
    // map of cost to go from start node to key node
    std::map< Position, double> gScore;
    gScore[key] =  0;
    
    return 0;
    while(!fScoreQueue.empty()){
        fScore topNode = fScoreQueue.top();
        
        Position pos = topNode.first;
        if(pos.first == x2 && pos.second == y2){
            path = reconstructPath(cameFrom, pos);
            return calculateCost(path);
        }

        fScoreQueue.pop();
        visited.insert(topNode.first);

        //Generate all neighbours
        GenNeighbour generator(topNode.first);
        for(int i=0; i< 8; i++){
            Position neighbour = generator.next();
            // If we've all ready visited this neighbour, skip it
            if(visited.count(neighbour) > 0){
                continue;
            }

            // If the two tile are not the same skip
            if(this->getTile(neighbour.first, neighbour.second) == this->getTile(pos.first, pos.second)){
                continue;
            }
            
            double tentativeGscore = gScore[topNode.first] + this->rectDistance(pos.first, pos.second, neighbour.first, neighbour.second );
            if(unvisited.count(neighbour) == 0){
                unvisited.insert(neighbour);
            } else if(tentativeGscore >= gScore[neighbour]){
                // This is not the best path
                continue;
            }
            // Record this new best path
            cameFrom[neighbour] = pos;
            gScore[neighbour] = tentativeGscore;
            fScoreQueue.push(fScore(neighbour, tentativeGscore + this->rectDistance(neighbour.first, neighbour.second, x2, y2)));
        }
    }
    return totalCost;
};
    
// sets tile type at location x y
void Grid::setTile(int x, int y, Tile tile){
    tiles[x][y] = tile;
};

double Grid::rectDistance(int x1, int y1, int x2, int y2) const{
    return sqrt((pow((x1 - x2),2 ) + pow((y1 - y2), 2)));
}

std::vector<Grid::Direction> Grid::reconstructPath(std::map< Position, Position > cameFrom, Position current) const{
    std::vector<Grid::Direction> path;
    path.push_back(getDirection(cameFrom[current], current));
    while(cameFrom.find(current) != cameFrom.end()){
        current = cameFrom[current];
        path.push_back(getDirection(cameFrom[current], current));
    }
    return path;
}

Grid::Direction Grid::getDirection(const Position current,const Position next) const{
    if(next.first == current.first+1 && next.second == current.second){
        return E; 
    } else if(next.first == current.first+1 && next.second == current.second + 1){
        return SE;
    } else if(next.first == current.first+1 && next.second == current.second - 1){
        return SE;
    } else if(next.first == current.first && next.second == current.second - 1){
        return N;
    } else if(next.first == current.first && next.second == current.second + 1){
        return S;
    } else if(next.first == current.first-1 && next.second == current.second + 1){
        return SW;
    }else if(next.first == current.first-1 && next.second == current.second){
        return NW;
    }else if(next.first == current.first-1 && next.second == current.second){
        return W;   
    } else {
        throw "Can't generate anymore neighbours";
    }
};

int Grid::calculateCost(const std::vector<Direction> path) const{
    int cost = 0;
    for(int a: path){
        if(a == N || a == S || a == W || a == E){
            cost += CARDINAL_COST;
        } else if( a == NE || a == NW || a == SE || a == SW){
            cost += DIAGONAL_COST;
        } else {
            throw "Direction not found";
        }
    }
    return cost;
}
